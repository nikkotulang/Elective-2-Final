/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problems;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 3rdyearaccount
 */
public class A_SquareOfaNumberTest {
    
    public A_SquareOfaNumberTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        A_SquareOfaNumber.main(args);
       // fail("The test case is a prototype.");
    }

    @Test
    public void testSquare() throws FileNotFoundException {
       Scanner sci = new Scanner(new File("src/TestCases/A1.in"));
     Scanner sco = new Scanner(new File("src/TestCases/A1.out"));
    
    int TestCases = sci.nextInt();
    
    while(TestCases > 0){
        
        int num = sci.nextInt();
        int actualResult = A_SquareOfaNumber.square(num);
        String actualResult2 = "";
        if(actualResult == -2){
            
          actualResult2 = "INVALID";
        }
        else if(actualResult == -1){
            
            actualResult2 = "TOO BIG";
        }
        
        else actualResult2 = actualResult+"";
    
        String expectedResult = sco.nextLine();
        assertEquals(expectedResult,actualResult2);
          
      
      
        
    TestCases--;    
    }
    
    System.out.println("######################");
    System.out.println("Test Case 1: Square Method Test Passed");
    System.out.println("######################");
    
    Scanner sci_1 = new Scanner(new File("src/TestCases/A2.in"));
     Scanner sco_1 = new Scanner(new File("src/TestCases/A2.out"));
    
    int TestCases_1 = sci_1.nextInt();
    
    while(TestCases_1 > 0){
        
        int num = sci_1.nextInt();
        int actualResult = A_SquareOfaNumber.square(num);
        String actualResult2 = "";
        if(actualResult == -2){
            
          actualResult2 = "INVALID";
        }
        else if(actualResult == -1){
            
            actualResult2 = "TOO BIG";
        }
        
        else actualResult2 = actualResult+"";
    
        String expectedResult = sco_1.nextLine();
        assertEquals(expectedResult,actualResult2);
          
      
      
        
    TestCases_1--;    
    }
    
    System.out.println("######################");
    System.out.println("Test Case 2: Square Method Test Passed");
    System.out.println("######################");
    
    
    Scanner sci_2 = new Scanner(new File("src/TestCases/A3.in"));
     Scanner sco_2 = new Scanner(new File("src/TestCases/A3.out"));
    
    int TestCases_2 = sci_2.nextInt();
    
    while(TestCases_2 > 0){
        
        int num = sci_2.nextInt();
        int actualResult = A_SquareOfaNumber.square(num);
        String actualResult2 = "";
        if(actualResult == -2){
            
          actualResult2 = "INVALID";
        }
        else if(actualResult == -1){
            
            actualResult2 = "TOO BIG";
        }
        
        else actualResult2 = actualResult+"";
    
        String expectedResult = sco_2.nextLine();
        assertEquals(expectedResult,actualResult2);
          
      
      
        
    TestCases_2--;    
    }
    
    System.out.println("######################");
    System.out.println("Test Case 3: Square Method Test Passed");
    System.out.println("######################");
    
    
}
}