/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problems;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * 
 */
public class A_SquareOfaNumber {
    
  public static void main(String[] args) throws FileNotFoundException{  
    Scanner sc = new Scanner(new File("src/TestCases/A3.in"));
    
    int TestCases = sc.nextInt();
    
    while(TestCases > 0){
        
        int num = sc.nextInt();
        int value = square(num);
      
        if(value==-1)System.out.println("TOO BIG");
        
        else if(value==-2)System.out.println("INVALID");
         
        else System.out.println(value);
        
    TestCases--;    
    }
   
   
    
  }

  
  public static int square(int num){
      
      if(num > 1000)return -1;
      else if(num < 0)return -2;
      else return num*num;
      
  }
}
